\connect postgres

DO
$$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'openclaw_user') THEN
    CREATE ROLE openclaw_user LOGIN PASSWORD 'openclaw_pass';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'evolution_user') THEN
    CREATE ROLE evolution_user LOGIN PASSWORD 'evolution_pass';
  END IF;
END
$$;

SELECT 'CREATE DATABASE openclaw OWNER openclaw_user'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'openclaw')
\gexec

SELECT 'CREATE DATABASE evolution OWNER evolution_user'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'evolution')
\gexec

REVOKE ALL ON DATABASE openclaw FROM PUBLIC;
REVOKE ALL ON DATABASE evolution FROM PUBLIC;
GRANT ALL PRIVILEGES ON DATABASE openclaw TO openclaw_user;
GRANT ALL PRIVILEGES ON DATABASE evolution TO evolution_user;
