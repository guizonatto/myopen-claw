import { copyFileSync, existsSync, mkdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const distroDir = path.resolve(scriptDir, "..");
const envDir = path.join(distroDir, "env");
const targetDir = process.cwd();
const targetEnv = path.join(targetDir, ".env");
const sourceEnv = path.join(envDir, ".env.example");

mkdirSync(targetDir, { recursive: true });

if (!existsSync(targetEnv)) {
  copyFileSync(sourceEnv, targetEnv);
  console.log(`Created ${targetEnv}`);
} else {
  console.log(`Keeping existing ${targetEnv}`);
}

console.log("Next step: run docker compose with the copied distro assets.");
