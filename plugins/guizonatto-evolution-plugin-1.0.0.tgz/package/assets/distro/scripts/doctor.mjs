import { spawnSync } from "node:child_process";

function run(args) {
  return spawnSync("docker", ["compose", ...args], {
    cwd: process.cwd(),
    encoding: "utf8",
    shell: process.platform === "win32",
  });
}

const ps = run(["ps"]);
if (ps.status !== 0) {
  console.error("docker compose ps failed");
  process.exit(ps.status ?? 1);
}

process.stdout.write(ps.stdout ?? "");

const health = run(["logs", "--tail", "50", "evolution-api"]);
if (health.status !== 0) {
  console.error("failed to read evolution-api logs");
  process.exit(health.status ?? 1);
}

process.stdout.write(health.stdout ?? "");
console.log("Doctor completed. Review compose status and evolution-api logs above.");
