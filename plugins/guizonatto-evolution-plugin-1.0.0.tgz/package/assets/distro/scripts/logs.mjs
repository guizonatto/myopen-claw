import { spawnSync } from "node:child_process";

const result = spawnSync("docker", ["compose", "logs", "--tail", "200"], {
  cwd: process.cwd(),
  stdio: "inherit",
  shell: process.platform === "win32",
});

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}
