import { spawnSync } from "node:child_process";

const result = spawnSync("docker", ["compose", "up", "-d"], {
  cwd: process.cwd(),
  stdio: "inherit",
  shell: process.platform === "win32",
});

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}
