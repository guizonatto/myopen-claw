# Evolution Plugin v1 Spec

## Scope

v1 includes:
- external OpenClaw plugin package
- channel id `evolution`
- setup flow for `baseUrl`, `apiKey`, `instanceName`, and `webhookPath`
- staged local distro assets for Evolution + PostgreSQL + Redis
- isolated PostgreSQL databases named `openclaw` and `evolution`
- webhook endpoint contract notes
- instance creation contract notes

v1 explicitly does not yet include:
- completed inbound runtime implementation
- completed outbound runtime implementation
- completed login or QR orchestration
- completed CLI helper commands

## Evolution API notes captured from docs

Source pages consulted during scaffold work:
- `https://doc.evolution-api.com/v2/pt/install/docker`
- `https://doc.evolution-api.com/v2/pt/requirements/database`
- `https://doc.evolution-api.com/v2/pt/requirements/redis`
- `https://doc.evolution-api.com/v2/pt/integrations/evolution-channel`

## Database and cache assumptions

The current docs indicate:
- database provider can be PostgreSQL or MySQL
- Redis is used separately for cache and broker-like runtime behavior
- the distro must pass explicit connection settings by environment variables

Current documented environment variables confirmed during scaffold work:
- `DATABASE_ENABLED=true`
- `DATABASE_PROVIDER=postgresql|mysql`
- `DATABASE_CONNECTION_URI=...`
- `DATABASE_CONNECTION_CLIENT_NAME=evolution_exchange`
- `DATABASE_SAVE_DATA_INSTANCE=true`
- `DATABASE_SAVE_DATA_NEW_MESSAGE=true`
- `DATABASE_SAVE_MESSAGE_UPDATE=true`
- `DATABASE_SAVE_DATA_CONTACTS=true`
- `DATABASE_SAVE_DATA_CHATS=true`
- `DATABASE_SAVE_DATA_LABELS=true`
- `DATABASE_SAVE_DATA_HISTORIC=true`
- `CACHE_REDIS_ENABLED=true`
- `CACHE_REDIS_URI=redis://host:6379/6`
- `CACHE_REDIS_PREFIX_KEY=evolution`
- `CACHE_REDIS_SAVE_INSTANCES=false`
- `CACHE_LOCAL_ENABLED=false`

The local default distro shape for this package is:
- PostgreSQL for Evolution
- Redis for Evolution
- separate `openclaw` database reserved for OpenClaw-side persistence

## Evolution Channel endpoint notes

The Evolution Channel docs currently show:

### Instance create

```http
POST /instance/create
```

Body example from docs:

```json
{
  "instanceName": "MinhaInstancia",
  "token": "123456",
  "number": "9876543210",
  "qrcode": false,
  "integration": "EVOLUTION"
}
```

### Inbound webhook entry

```http
POST /webhook/evolution
```

Payload example from docs:

```json
{
  "numberId": "1234567",
  "key": {
    "remoteJid": "557499879409",
    "fromMe": false,
    "id": "ABC1234"
  },
  "pushName": "Davidson",
  "message": {
    "conversation": "Qual o seu nome?"
  },
  "messageType": "conversation"
}
```

## Notes for implementation

- `key.fromMe === true` must be ignored to avoid loops.
- `key.id` should be the first candidate for dedupe.
- `key.remoteJid` should become the primary sender or target identifier for direct messages.
- `message.conversation` is the first text path to support.
- The channel runtime should treat this spec as frozen until a new real payload sample proves otherwise.

## Additional API notes confirmed during scaffold work

### Set webhook

The current webhook docs show instance-based webhook configuration through:

```http
POST /webhook/instance
```

Example body:

```json
{
  "url": "https://example.com/webhook/evolution",
  "webhook_by_events": false,
  "webhook_base64": false,
  "events": [
    "QRCODE_UPDATED",
    "MESSAGES_UPSERT",
    "MESSAGES_UPDATE",
    "MESSAGES_DELETE",
    "SEND_MESSAGE",
    "CONNECTION_UPDATE"
  ]
}
```

Useful companion lookup endpoint:

```http
GET /webhook/find/{instance}
```

### Send text

The current API reference shows:

```http
POST /message/sendText/{instance}
```

Example body:

```json
{
  "number": "5531999999999",
  "text": "Ola!",
  "delay": 0,
  "linkPreview": true
}
```
