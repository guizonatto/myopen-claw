# OpenClaw Evolution Plugin

Draft external plugin package for integrating Evolution API with OpenClaw.

This package is being staged inside the OpenClaw repo as a development scaffold.
The target distribution model remains an external package installed with:

```bash
openclaw plugins install @scope/openclaw-evolution
```

During development, install from a local path:

```bash
openclaw plugins install ./packages/openclaw-evolution
```

Or install from a tarball:

```bash
cd packages/openclaw-evolution
npm pack
openclaw plugins install ./openclaw-evolution-<version>.tgz
```

## Current Scope

The current scaffold covers:
- channel manifest and entrypoints
- channel config schema
- account resolution
- setup adapter
- local distro assets for PostgreSQL + Redis + Evolution
- init SQL for isolated `openclaw` and `evolution` databases

Still pending:
- Evolution HTTP client
- webhook inbound pipeline
- outbound text delivery
- channel status
- CLI helper commands

## Local Distro Shape

The bundled distro assets assume:
- one PostgreSQL server
- one Redis server
- one Evolution API service
- two isolated PostgreSQL databases:
  - `openclaw`
  - `evolution`

The Evolution service must only use the `evolution` database.

## Files

- `SPEC.md` - v1 scope and endpoint notes
- `assets/distro/compose.yml` - bundled local stack
- `assets/distro/compose.external-db.yml` - external PostgreSQL variant
- `assets/distro/sql/001-init-databases.sql` - creates the two databases and roles
